# Base de datos del proyecto caremod

Base de datos: oracle db
back: ·net
